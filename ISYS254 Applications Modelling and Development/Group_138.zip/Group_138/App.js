/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 *last edited by: Ronnie Ladao - 44096801 DTG2359053019
 */

import React, { Component } from 'react';
import {
View,
StyleSheet
} from 'react-native';
import { Router, Scene } from 'react-native-router-flux';


import Menu from './components/menu';
import Summary from './components/summary';
import Welcome from './components/welcome';

export default class App extends Component<Props> {
  //console.disableYellowBox = true;
  render() {
    return (
      <View style={styles.container}>
        <Router>
          <Scene key="root">
            <Scene  initial key="welcome" component = {Welcome} title='Welcome to Campus Common System' />
            <Scene  key="menu" component = {Menu} title='Menu Items' />
            <Scene  key="summary" component = {Summary} title='Order Summary' />
          </Scene>
        </Router>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

});
