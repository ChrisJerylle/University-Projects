    /*
    *last edited by: Ronnie Ladao - 44096801 DTG2318052719
    */

    import React, { Component } from 'react';
    import {
    Platform,
    StyleSheet,
    Text,
    View,
    TextInput,
    Image,
    TouchableOpacity,
    } from 'react-native';

    import { Dropdown } from 'react-native-material-dropdown';
    import { Actions } from 'react-native-router-flux';

    export default class menu extends Component {

    constructor(props){
      super(props);
      let params = this.props.navigation.state.params;
      this.state = {
    businessName: params.businessName,
    foodName:"00",
    drinkName:"0",
    drinkQty: 0,
    foodQty:0
    };

    this.foodItem =
    [
    {value: 'Starter - ANTIPASTO to SHARE for 4 - $20',},
    {value: 'Starter - CAPRESE - $15',},
    {value: 'Pizza - PERI CHICKEN - $16',},
    {value: 'Pizza - THE GODFATHER - $18',},
    {value: 'Vegan - MARGHERITA PIZZA - $17',}
    ];
    this.drinkItem =
    [
    {value: 'SAN PELLIGRINO - $5',},
    {value: 'FRUIT JUICE MOCKTAIL - $7',},
    {value: 'CORONA BOTTLE BEER - $8',},
    {value: 'COOLRIDGE - $3',},
    {value: 'HANN SUPER DRY TAP BEER - $6',}
    ];
    this.itemQty =
    [
    {value:1,},
    {value:2,},
    {value:3,},
    {value:4,},
    {value:5,}
  ];
    }

    render() {
      return (

      <View style={styles.container}>
        <View style={styles.imageHeader}>
          <Image
            source={require('../components/cc2.png')}
            containerStylestyle={styles.imageHeader}
            />
        </View>

        {this.displayPlaceofBusiness()}

        {this.displayNowServing()}

            <View style={styles.viewRow1}>
                  <Dropdown
                        containerStyle={styles.dropdown1}
                        label='|* Food Items *'
                        data={this.foodItem}
                        onChangeText={(chosenFood) => this.setState({
                          foodName:chosenFood})}
                  />
                  <Dropdown
                        containerStyle={styles.dropdown2}
                        label=' Qty:'
                        data={this.itemQty}
                        onChangeText={(chosenQty) => this.setState({
                          foodQty:chosenQty})}
                  />
          </View>
          <View style={styles.viewRow2}>
                  <Dropdown
                        containerStyle={styles.dropdown1}
                        label='|* Drinks *'
                        data={this.drinkItem}
                        onChangeText={(chosenDrink) => this.setState({
                            drinkName:chosenDrink})}
                  />
                  <Dropdown
                        containerStyle={styles.dropdown2}
                        label=' Qty:'
                        data={this.itemQty}
                        onChangeText={(chosenQty) => this.setState({
                              drinkQty:chosenQty})}
                  />
          </View>

          <View style={styles.viewRow3}>
            <TouchableOpacity
              style={styles.button}
              onPress={this.onPressEvent.bind(this)}>
                <Text style={styles.buttonText}>
                  Proceed
                </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.imagelogo}>
            <Image
              source={require('../components/mqlogo.png')}
              containerStylestyle={styles.imagelogo}
              />
          </View>

      </View>
      );
    }
    displayPlaceofBusiness(){
        if (this.state.businessName!="")
        return  <Text style={styles.header}>{this.state.businessName}</Text>;
        else
        return <Text style={styles.headerNoBusiness}> ** Oops, sorry no place of business selected. **</Text>;
    }
    displayNowServing(){
        if (this.state.businessName!="")
        return  <Text style={styles.subheader}>  -|-  Now Serving  -|- </Text>;
        else
        return <Text style={styles.subheaderNoBusiness}>Please select Back Arrow to continue. Thank You.</Text>;
    }
    onPressEvent(){
      let temp1 = this.state.businessName;
      let temp2 = this.state.foodName;
      let temp3 = this.state.foodQty;
      let temp4 = this.state.drinkName;
      let temp5 = this.state.drinkQty;

      let temp6=parseInt(temp2.substring(temp2.length-2,temp2.length));
      let foodPrice=temp6*this.state.foodQty;

      let temp7=parseInt(temp4.substring(temp4.length-1,temp4.length));
      let drinkPrice=temp7*this.state.drinkQty;

      let totalOrdered=((temp6*this.state.foodQty)+(temp7*this.state.drinkQty));

    Actions.summary({
      businessName: temp1,

      foodName:temp2,
      foodQty: temp3,
      foodPrice:  foodPrice,

      drinkName: temp4,
      drinkQty:  temp5,
      drinkPrice:  drinkPrice,

      totalOrdered: totalOrdered

    });
    }
    }

    const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: 'white',
      justifyContent: 'flex-start',
      alignItems: 'center',
    },
    imageHeader: {
      flex:1,
      height: 128,
      width: 400,
      marginTop: 10,
      alignItems: 'center',
    },
    header: {
      marginTop: 10,
      fontSize: 40,
      fontWeight: 'bold',
      color: 'white',
      textAlign: 'center',
    },
    headerNoBusiness: {
      marginTop: 10,
      fontSize: 20,
      fontWeight: 'bold',
      color: 'yellow',
      textAlign: 'center',
    },
    subheader: {
      marginTop: 10,
      fontSize: 20,
      color: 'red',
      textAlign: 'center',
    },
    subheaderNoBusiness: {
      marginTop: 10,
      fontSize: 15,
      color: 'red',
      textAlign: 'center',
    },
    viewRow1:{
      flex:.80,
      flexDirection:'row',
      alignItems:'center',
      justifyContent:'center',
    },
    viewRow2:{
      flex: .90,
      flexDirection:'row',
      alignItems:'center',
      justifyContent:'center',
    },
    viewRow3:{
      flex: .90,
      flexDirection:'row',
      alignItems:'center',
      justifyContent:'center',
    },
    dropdown1: {
      flex: 4,
      marginTop: 40,
    },
    dropdown2:{
      flex: 1,
      marginTop: 40,
    },
    imagelogo: {
      flex:1,
      height: 65,
      width: 175,
      marginTop: 200,
      alignItems: 'center',
    },
    button:{
      width: '70%',
      height: 50,
      justifyContent: 'center',
      backgroundColor:'black',
      height: 45,
      width: 140,
      alignItems: 'center',
      marginTop: 180,
      borderRadius:10,
      borderWidth: 1,
    },
    buttonText:{
      textAlign: 'center',
      fontSize: 22,
      fontWeight: 'bold',
      color: 'white',
    }
    });
