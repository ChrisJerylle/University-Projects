/*
*last edited by: Ronnie Ladao - 44096801 DTG2359053019
*/

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  TextInput,
  Image,
  TouchableOpacity,
} from 'react-native';

import { Dropdown } from 'react-native-material-dropdown';
import { Actions } from 'react-native-router-flux';

export default class welcome extends Component {

  constructor(props){
    super(props);

    let params = this.props.navigation.state.params;
    this.state = {
      finalValue: params.businessName
    };

    this.state = {
      businessName:"",
    }

    this.placeOfBusiness =
    [
      {value: 'Ubar',},
      {value: 'Boost Juice',},
      {value: 'Iku Wholefoods',},
      {value: 'Sushi World',},
      {value: 'Thai Kiosk',}
    ];
  }

  render() {

    return (
      <View style={styles.container}>

      <View style={styles.imageHeader}>
      <Image
      source={require('../components/cc2.png')}
      containerStylestyle={styles.imageHeader}
      />
      </View>

      <View style={styles.row1}>
      <Dropdown
      containerStyle={styles.dropdown1}
      label='Choose the place of business'
      data={this.placeOfBusiness}
      onChangeText={(chosenBusiness) => this.setState({
        businessName:chosenBusiness})}
        />
        </View>

        <View style={styles.row2}>
        <TouchableOpacity
        style={styles.button}
        onPress={this.onPressEvent.bind(this)}>

        <Text style={styles.buttonText}>
        Proceed
        </Text>
        </TouchableOpacity>
        </View>

        <View style={styles.imagelogo}>
        <Image
        source={require('../components/mqlogo.png')}
        containerStylestyle={styles.imagelogo}
        />
        </View>

        </View>
      );
    }
    onPressEvent(){
      let temp = this.state.businessName;

      Actions.menu({
        businessName:temp
      });
    }
  }
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: 'white',
      justifyContent: 'flex-start',
      alignItems: 'center',
    },
    header: {
      fontSize: 30,
      fontWeight:'bold',
      marginTop: 30,
      textAlign: 'center',
    },
    imageHeader: {
      flex:1,
      height: 128,
      width: 400,
      marginTop: 10,
      alignItems: 'center',
    },
    imagelogo: {
      flex:1,
      height: 65,
      width: 175,
      marginTop: 180,
      alignItems: 'center',
    },
    row1:{
      flex:1,
      flexDirection:'row',
      alignItems:'center',
      justifyContent:'center',
    },
    row2:{
      flex:2,
      flexDirection:'row',
      alignItems:'center',
      justifyContent:'center',
    },
    dropdown1: {
      flex: .60,
      marginTop: 80,
    },
    button:{
      width: '70%',
      height: 50,
      justifyContent: 'center',
      backgroundColor:'black',
      height: 45,
      width: 140,
      alignItems: 'center',
      //marginTop: 280,
      borderRadius:10,
      borderWidth: 1,
    },
    buttonText:{
      textAlign: 'center',
      fontSize: 22,
      fontWeight: 'bold',
      color: 'white',
    }
  });
