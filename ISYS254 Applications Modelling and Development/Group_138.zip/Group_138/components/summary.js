  /*
  *last edited by: Ronnie Ladao - 44096801 DTG2359053019
  */
  import React, { Component } from 'react';
  import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    Image
  } from 'react-native';

  export default class summary extends Component {
    constructor(props) {
      super(props);
      let params = this.props.navigation.state.params;
      this.state = {
        businessName: params.businessName,
        foodName:  params.foodName,
        foodQty:  params.foodQty,
        foodPrice:  params.foodPrice,
        drinkName: params.drinkName,
        drinkQty:  params.drinkQty,
        drinkPrice:  params.drinkPrice,
        totalOrdered: params.totalOrdered
      };
    }

    render() {
      return (
        <View style={styles.container}>
          <Text style={styles.header}>
            {this.state.businessName}
          </Text>

            {this.displayThankYouIfOrdered()}
            {this.displaySummaryDetailHeader()}
            {this.displayFoodDetail()}
            {this.displayDrinkDetail()}
            {this.displayTotalOrdered()}
            {this.displayWaitTime()}

        <View style={styles.imagelogo}>
          <Image
            source={require('../components/mqlogo.png')}
          />
        </View>

          <Text style={styles.footer}>       App developed by;</Text>
          <Text style={styles.footer}>       Ronnie Ladao - 44096801</Text>
          <Text style={styles.footer}>       Lorenzo Casaol - 44911017</Text>
          <Text style={styles.footer}>       Chris Jerylle Vargas Oidem - 45476624</Text>

        </View>

      );
    }
      displayThankYouIfOrdered(){
        if (this.state.totalOrdered>0)
          return  <Text style={styles.thankyou}>:-)   Thank you for your order. Come Again.    (-: </Text>;
        else
          return  <Text style={styles.thankyou}> Oops, sorry you have not properly placed your order. </Text>;
      }
      displaySummaryDetailHeader(){
        if (this.state.totalOrdered>0)
          return   <Text style={styles.summarydetailheader}> Qty | Item | Extended Price</Text>;
        else
          return (<View></View>);
      }
      displayFoodDetail(){
        if (this.state.foodName!="00")
          if (this.state.foodQty>0)
        return <Text style={styles.fooddrinkdetail}>  {this.state.foodQty} {this.state.foodName} each -> ${this.state.foodPrice}</Text>;
        else
          return (<View></View>);
          else
            return (<View></View>);
      }
      displayDrinkDetail(){
        if (this.state.drinkName!="0")
          if (this.state.drinkQty>0)
        return <Text style={styles.fooddrinkdetail}>  {this.state.drinkQty} {this.state.drinkName} each -> ${this.state.drinkPrice}</Text>;
        else
          return (<View></View>);
          else
            return (<View></View>);
      }
      displayTotalOrdered(){
        if (this.state.totalOrdered>0)
          return <Text style={styles.totalordered}> TOTAL ORDER (includes GST):  ${this.state.totalOrdered}</Text>;
        else
          return <Text style={styles.thankyou}>Please try again, select Back Arrow to place your order.  Thank you.</Text>;
      }
      displayWaitTime(){
        if (this.state.totalOrdered>0)
          return <Text style={styles.message}>** Your order will be ready for pickup in 15 minutes. **</Text>;
        else
          return (<View></View>);
      }
    }

    const styles = StyleSheet.create({
      container: {
        flex: 1,
        backgroundColor: 'white',

      },
      header: {
        marginTop: 10,
        fontSize: 30,
        fontWeight: 'bold',
        color: 'darkblue',
        textAlign: 'center',
      },
      thankyou: {
        marginTop: 10,
        fontSize: 15,
        fontWeight: 'bold',
        color: 'red',
        textAlign: 'center',
      },
      summarydetailheader: {
        marginTop: 30,
        fontSize: 18,
        fontWeight: 'bold',
        color: 'darkblue',
        textAlign: 'left',
      },
      fooddrinkdetail: {
        marginTop: 5,
        fontSize: 15,
        color: 'darkblue',
        textAlign: 'left',
      },
      totalordered: {
        marginTop: 50,
        fontSize: 18,
        fontWeight: 'bold',
        color: 'darkblue',
        textAlign: 'left',
      },
      message: {
        justifyContent:'flex-end',
        fontSize: 14,
        fontWeight: 'bold',
        color: 'red',
        textAlign: 'center',
      },
      imagelogo: {
        height: 37,
        width: 80,
        marginTop: 80,
        justifyContent:'flex-end',
      },
      footer: {
        justifyContent:'flex-end',
        fontSize: 10,
        fontWeight: 'bold',
        color: 'black',
        textAlign: 'left',
      },
    });
